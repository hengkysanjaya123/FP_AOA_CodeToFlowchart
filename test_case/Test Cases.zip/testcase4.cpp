int k = 2;
int c = 5;
while(k<c){
    cout << "Hello World";
}