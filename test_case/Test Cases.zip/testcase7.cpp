int a = 3;
int c = 10;
while(c > 0){
    if(a > 1){
        c++;
    }
    cout << "Hello";
}