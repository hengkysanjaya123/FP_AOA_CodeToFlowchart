int a = 10;
int b = 20;
while(a < 30){
    for(int i = 0; i < b; i++){
        cout << "Hello its me";
    }
    a++;
};