int input;
int i=30;
int j=10;
cout << "enter number :";
cin >> input;
if (input > 10){
while(j < 20){
if( i < j){
cout << "What is this";
}
cout << "Hello";
cout << "No";
}
cout << "Added";
while( i < 5){
cout << "Still smaller than 5";
}

cout << "Nice";
}int input;
int i=30;
int j=10;
cout << "enter number :";
cin >> input;
if (input > 10){
while(j < 20){
if( i < j){
cout << "What is this";
}
cout << "Hello";
cout << "No";
}
cout << "Added";
while( i < 5){
cout << "Still smaller than 5";
}

cout << "Nice";
}int input;
int i=30;
int j=10;
cout << "enter number :";
cin >> input;
if (input > 10){
while(j < 20){
if( i < j){
cout << "What is this";
}
cout << "Hello";
cout << "No";
}
cout << "Added";
while( i < 5){
cout << "Still smaller than 5";
}

cout << "Nice";
}int input;
int i=30;
int j=10;
cout << "enter number :";
cin >> input;
if (input > 10){
while(j < 20){
if( i < j){
cout << "What is this";
}
cout << "Hello";
cout << "No";
}
cout << "Added";
while( i < 5){
cout << "Still smaller than 5";
}

cout << "Nice";
}int input;
int i=30;
int j=10;
cout << "enter number :";
cin >> input;
if (input > 10){
while(j < 20){
if( i < j){
cout << "What is this";
}
cout << "Hello";
cout << "No";
}
cout << "Added";
while( i < 5){
cout << "Still smaller than 5";
}

cout << "Nice";
}int input;
int i=30;
int j=10;
cout << "enter number :";
cin >> input;
if (input > 10){
while(j < 20){
if( i < j){
cout << "What is this";
}
cout << "Hello";
cout << "No";
}
cout << "Added";
while( i < 5){
cout << "Still smaller than 5";
}

cout << "Nice";
}
for(int k = 0; i < 5; k++){
    cout << "Hello its me";
}