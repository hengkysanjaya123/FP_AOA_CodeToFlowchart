bool flag = false;
if(flag == false){
    cout << "Nice";
}
else{
    cout << "Hello World";
}