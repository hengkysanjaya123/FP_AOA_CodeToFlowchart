int a = 1;
int num = 20;
while(a < num){
if(a > 10){
while (a < 20){
cout << "Its greater than 10";
}
while (a < 20){
cout << "Its greater than 10";
}
while (a < 20){
cout << "Its greater than 10";
}
while (a < 20){
cout << "Its greater than 10";
}
}
}
while(a < num){
if(a > 10){
while (a < 20){
cout << "Its greater than 10";
}
while (a < 20){
cout << "Its greater than 10";
}
while (a < 20){
cout << "Its greater than 10";
}
while (a < 20){
cout << "Its greater than 10";
}
}
}