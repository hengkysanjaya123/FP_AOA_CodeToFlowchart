int k = 2;
int c = 5;
cout << k +c;