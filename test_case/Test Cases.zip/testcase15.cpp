int b = 10;
int c = 15;

while(b == 5){
while(a < 10000){
if(c == 0){
if(b == c){
cout << "test";
}
}
}
}
while(b == 5){
while(a < 10000){
if(c == 0){
if(b == c){
cout << "test";
}
}
}
}while(b == 5){
while(a < 10000){
if(c == 0){
if(b == c){
cout << "test";
}
}
}
}while(b == 5){
while(a < 10000){
if(c == 0){
if(b == c){
cout << "test";
}
}
}
}