int a = 10;
int b = 20;
if(a<b){
    while(a < 15){
    a++;
while(a < 15){
a++;
while(a < 15){
a++;
}
}
