int a = 10;
int b = 15;
while(a < b){
    while(a <15){
        a++;
}
    cout << "test";
}