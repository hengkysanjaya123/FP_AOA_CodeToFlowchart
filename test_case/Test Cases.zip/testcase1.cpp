int b = 10;
int c = 15;
int d = 20;