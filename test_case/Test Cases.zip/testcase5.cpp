int a = 3;
int b = 2;
if(a < b){
    a+b;
}
else{
    "Wrong input";
}